package com.amita.serkomkpu.util

fun emptyString(): String = ""

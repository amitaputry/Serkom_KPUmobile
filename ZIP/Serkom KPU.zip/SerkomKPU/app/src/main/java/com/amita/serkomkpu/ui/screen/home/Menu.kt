package com.amita.serkomkpu.ui.screen.home

data class Menu(
    val id: Int = 0,
    val image: Int,
    val title: String,
)
package com.amita.serkomkpu

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SerkomKpuApplication : Application()

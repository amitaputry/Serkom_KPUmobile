package com.amita.serkomkpu.ui.screen.home

import androidx.annotation.DrawableRes

data class CarouselItem(
    val id: Int = 0,
    @DrawableRes val image: Int
)
